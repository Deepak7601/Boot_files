package com.mobileshop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mobileshop.dao.AdminDao;
import com.mobileshop.dao.CartDao;
import com.mobileshop.dao.CategoryDao;
import com.mobileshop.dao.OrderDao;
import com.mobileshop.dao.ProductDao;
import com.mobileshop.dao.UserDao;

@SpringBootApplication
public class OnlineMobileApplication implements CommandLineRunner {

	@Autowired
	private ProductDao productDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private OrderDao orderDao;
	
	@Autowired
	private CartDao cartDao;
	
	@Autowired
	private AdminDao admnDao;
	
	@Autowired
	private CategoryDao categoryDao;
	
	public static void main(String[] args) {
		SpringApplication.run(OnlineMobileApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		this.productDao.createProductTable();
		this.userDao.createUserTable();
		this.categoryDao.createCategoryTable();
		this.admnDao.createAdminTable();
		this.cartDao.createCartTable();
		this.orderDao.createOrderTable();
	}

}
