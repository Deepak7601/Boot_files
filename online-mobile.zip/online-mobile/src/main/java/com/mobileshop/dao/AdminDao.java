package com.mobileshop.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mobileshop.model.Admin;
import com.mobileshop.modelmapper.AdminMapper;



@Repository
public class AdminDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public void createAdminTable() {
		
		String query = "CREATE TABLE IF NOT EXISTS ADMIN(id int primary key auto_increment,city varchar(255), emailid varchar(255), firstName varchar(255), lastName varchar(255), mobileNo varchar(255), password varchar(255), pincode varchar(255),"
				+ "street varchar(255))";
		this.jdbcTemplate.update(query);
		System.out.println("create table admin query executed");
		
		
	}
	
	
	public int save(Admin admin) {
		
		String query = "INSERT INTO admin (city, emailid, firstname, lastname, mobileno, password, pincode,street) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
				
		int update = this.jdbcTemplate.update(query, new Object[] {admin.getCity(),admin.getEmailid(), admin.getFirstname(), admin.getLastname(), admin.getMobileno(), admin.getPassword(), admin.getPincode(), admin.getStreet()});
		
		return update;
	}
	
	public Admin getAdminByEmailIdAndPassword(String emailid, String password) {
		
		String query = "select * from ADMIN where emailid='"+emailid+"' and password='"+password+"'";
		List <Admin> admins = this.jdbcTemplate.query(query, new AdminMapper());
		
		if(admins == null) {
			return null;
		}
		
		else {
			return admins.get(0);
		}
		
	}
	
}
