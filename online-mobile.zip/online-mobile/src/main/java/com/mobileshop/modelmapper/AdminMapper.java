package com.mobileshop.modelmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mobileshop.model.Admin;


public class AdminMapper implements RowMapper<Admin>  {
	
	@Override
	public Admin mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Admin admin = new Admin();
		admin.setId(rs.getInt("id"));
		admin.setCity(rs.getString("city"));
		admin.setEmailid(rs.getString("emailid"));
		admin.setFirstname(rs.getString("firstname"));
		admin.setLastname(rs.getString("lastname"));
		admin.setMobileno(rs.getString("mobileno"));
		admin.setPassword(rs.getString("password"));
		admin.setPincode(rs.getString("pincode"));
		admin.setStreet(rs.getString("street"));
		return admin;
		
	}

}
